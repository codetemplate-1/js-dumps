// LayoutContext.tsx
import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
} from "react";
import { commonFieldMapping } from "./commonFieldMapping";

type LayoutContextType = {
  unifiedFields: string[];
  registerProduct: (productType: string) => void;
};

const LayoutContext = createContext<LayoutContextType | undefined>(undefined);

export const LayoutProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [registeredProducts, setRegisteredProducts] = useState<string[]>([]);
  const [unifiedFields, setUnifiedFields] = useState<string[]>([]);

  const registerProduct = (productType: string) => {
    setRegisteredProducts((prevProducts) => [...prevProducts, productType]);
  };

  useEffect(() => {
    const fieldScores: Record<string, number> = {};

    registeredProducts.forEach((productType) => {
      commonFieldMapping[productType].forEach((field) => {
        if (
          !(field.name in fieldScores) ||
          field.score < fieldScores[field.name]
        ) {
          fieldScores[field.name] = field.score;
        }
      });
    });

    const sortedFields = Object.keys(fieldScores).sort(
      (a, b) => fieldScores[a] - fieldScores[b]
    );
    setUnifiedFields(sortedFields);
  }, [registeredProducts]);

  return (
    <LayoutContext.Provider value={{ unifiedFields, registerProduct }}>
      {children}
    </LayoutContext.Provider>
  );
};

export const useLayout = (): LayoutContextType => {
  const context = useContext(LayoutContext);
  if (!context) {
    throw new Error("useLayout must be used within a LayoutProvider");
  }
  return context;
};
