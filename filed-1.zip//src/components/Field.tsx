// Field.tsx
import React from "react";
import { Field as FieldType } from "./productSchemas";

interface FieldProps {
  field: FieldType;
}

const Field: React.FC<FieldProps> = ({ field }) => {
  switch (field.type) {
    case "number":
      return (
        <input type="number" name={field.name} required={field.required} />
      );
    case "select":
      return (
        <select name={field.name} required={field.required}>
          {field.options?.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      );
    case "date":
      return <input type="date" name={field.name} required={field.required} />;
    default:
      return null;
  }
};

export default Field;
