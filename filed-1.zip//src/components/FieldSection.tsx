// FieldSection.tsx
import React from "react";
import Field from "./Field";
import { Field as FieldType } from "./productSchemas";

interface FieldSectionProps {
  fieldName: string;
  fields: FieldType[];
}

const FieldSection: React.FC<FieldSectionProps> = ({ fieldName, fields }) => {
  const field = fields.find((f) => f.name === fieldName);
  return (
    <div className="field-section">
      {field ? (
        <Field key={field.name} field={field} />
      ) : (
        <div className="blank-space" />
      )}
    </div>
  );
};

export default FieldSection;
