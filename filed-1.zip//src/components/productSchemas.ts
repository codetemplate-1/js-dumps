// productSchemas.ts
export type Field = {
  name: string;
  label: string;
  type: string;
  options?: string[];
  required: boolean;
};

export type Section = {
  sectionName: string;
  fields: Field[];
};

export type ProductSchema = {
  productType: string;
  sections: Section[];
};

export const productSchemas: Record<string, ProductSchema> = {
  "FX Vanilla": {
    productType: "FX Vanilla",
    sections: [
      {
        sectionName: "Trade Details",
        fields: [
          {
            name: "Notional",
            label: "Notional",
            type: "number",
            required: true,
          },
          {
            name: "Buy/Sell",
            label: "Buy/Sell",
            type: "select",
            options: ["Buy", "Sell"],
            required: true,
          },
          { name: "Expiry", label: "Expiry", type: "date", required: true },
          {
            name: "Model",
            label: "Model",
            type: "select",
            options: ["SmileSingleVolAnalytic", "OtherModel"],
            required: true,
          },
          {
            name: "Option",
            label: "Option",
            type: "select",
            options: ["EUR Option", "USD Option"],
            required: false,
          },
          { name: "Strike", label: "Strike", type: "number", required: false },
          {
            name: "Payoff Choices",
            label: "Payoff Choices",
            type: "select",
            options: ["Deliverable", "Non-Deliverable"],
            required: true,
          },
        ],
      },
    ],
  },
  "FX Barrier": {
    productType: "FX Barrier",
    sections: [
      {
        sectionName: "Trade Details",
        fields: [
          {
            name: "Notional",
            label: "Notional",
            type: "number",
            required: true,
          },
          {
            name: "Buy/Sell",
            label: "Buy/Sell",
            type: "select",
            options: ["Buy", "Sell"],
            required: true,
          },
          { name: "Expiry", label: "Expiry", type: "date", required: true },
          {
            name: "Model",
            label: "Model",
            type: "select",
            options: ["LSVMS", "OtherModel"],
            required: true,
          },
          {
            name: "Option",
            label: "Option",
            type: "select",
            options: ["EUR Option", "USD Option"],
            required: false,
          },
          { name: "Strike", label: "Strike", type: "number", required: false },
          {
            name: "Payoff Choices",
            label: "Payoff Choices",
            type: "select",
            options: ["Deliverable", "Non-Deliverable"],
            required: true,
          },
        ],
      },
      {
        sectionName: "Barrier Details",
        fields: [
          {
            name: "Barrier 1",
            label: "Barrier 1",
            type: "select",
            options: ["KO", "KI"],
            required: true,
          },
          {
            name: "Start date",
            label: "Start date",
            type: "date",
            required: false,
          },
          {
            name: "End date",
            label: "End date",
            type: "date",
            required: false,
          },
          { name: "Level", label: "Level", type: "number", required: false },
          {
            name: "Side",
            label: "Side",
            type: "select",
            options: ["OD", "KD"],
            required: false,
          },
        ],
      },
    ],
  },
};
