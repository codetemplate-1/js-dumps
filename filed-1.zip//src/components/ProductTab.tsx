// ProductTab.tsx
import React, { useEffect } from "react";
import FieldSection from "./FieldSection";
import { useLayout } from "./LayoutContext";
import { ProductSchema } from "./productSchemas";

interface ProductTabProps {
  productType: string;
  schema: ProductSchema;
}

const ProductTab: React.FC<ProductTabProps> = ({ productType, schema }) => {
  const { registerProduct, unifiedFields } = useLayout();

  useEffect(() => {
    registerProduct(productType);
  }, []);

  // Flatten the fields from all sections in the schema
  const allFields = schema.sections.flatMap((section) => section.fields);

  return (
    <div className="product-tab">
      {unifiedFields.map((fieldName, index) => {
        const field = allFields.find((f) => f.name === fieldName);
        return field ? (
          <FieldSection key={index} fieldName={field.name} fields={[field]} />
        ) : (
          <div key={index} className="blank-space"></div>
        );
      })}
    </div>
  );
};

export default ProductTab;

// interface ProductTabProps {
//   productType: string;
//   schema: ProductSchema;
// }

// const ProductTab: React.FC<ProductTabProps> = ({ productType, schema }) => {
//   const { registerProduct } = useLayout();

//   useEffect(() => {
//     registerProduct(productType);
//   }, [productType, registerProduct]);

//   return (
//     <div className="product-tab">
//       {schema.sections.flatMap((section) =>
//         section.fields.map((field, index) => (
//           <FieldSection
//             key={index}
//             fieldName={field.name}
//             fields={section.fields}
//           />
//         ))
//       )}
//     </div>
//   );
// };`

// export default ProductTab;

// interface ProductTabProps {
//   productType: string;
//   schema: ProductSchema;
// }

// const ProductTab: React.FC<ProductTabProps> = ({ productType, schema }) => {
//   const { registerProduct, unifiedFields } = useLayout();

//   useEffect(() => {
//     registerProduct(productType);
//   }, [productType, registerProduct]);

//   return (
//     <div className="product-tab">
//       {unifiedFields.map((fieldName, index) => {
//         const field = schema.sections
//           .flatMap((section) => section.fields)
//           .find((f) => f.name === fieldName);
//         return field ? (
//           <FieldSection key={index} fieldName={field.name} fields={[field]} />
//         ) : (
//           <div key={index} className="blank-space"></div>
//         );
//       })}
//     </div>
//   );
// };

// export default ProductTab;
