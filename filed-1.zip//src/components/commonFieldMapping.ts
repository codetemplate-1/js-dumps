// commonFieldMapping.ts
type FieldWithScore = {
  name: string;
  score: number;
};

export const commonFieldMapping: Record<string, FieldWithScore[]> = {
  "FX Vanilla": [
    { name: "Notional", score: 1 },
    { name: "Buy/Sell", score: 2 },
    { name: "Expiry", score: 3 },
    { name: "Model", score: 4 },
    { name: "Option", score: 5 },
    { name: "Strike", score: 6 },
    { name: "Payoff Choices", score: 12 },
  ],
  "FX Barrier": [
    { name: "Notional", score: 1 },
    { name: "Buy/Sell", score: 2 },
    { name: "Expiry", score: 3 },
    { name: "Model", score: 4 },
    { name: "Option", score: 5 },
    { name: "Strike", score: 6 },
    { name: "Barrier 1", score: 7 },
    { name: "Start date", score: 8 },
    { name: "End date", score: 9 },
    { name: "Level", score: 10 },
    { name: "Side", score: 11 },
    { name: "Payoff Choices", score: 12 },
  ],
  // Add other products here
};
