// FieldLabelPanel.tsx
import React from "react";
import { useLayout } from "./LayoutContext";

const FieldLabelPanel: React.FC = () => {
  const { unifiedFields } = useLayout();

  return (
    <div className="field-label-container">
      <div className="field-label-panel">
        {unifiedFields.map((label, index) => (
          <div key={index} className="label">
            {label}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FieldLabelPanel;
