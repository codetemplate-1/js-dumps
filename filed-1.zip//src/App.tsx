// App.tsx
import React, { useState } from "react";
import ProductTab from "./components/ProductTab";
import FieldLabelPanel from "./components/FieldLabelPanel";
import { LayoutProvider } from "./components/LayoutContext";
import { productSchemas } from "./components/productSchemas";
import { ProductSchema } from "./components/productSchemas";

interface Product {
  productType: string;
  schema: ProductSchema;
}

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  const addProduct = (productType: string) => {
    const schema = productSchemas[productType];
    setProducts([...products, { productType, schema }]);
  };

  return (
    <LayoutProvider>
      <div className="app">
        <FieldLabelPanel />
        <div className="product-container">
          {products.map(({ productType, schema }, index) => (
            <div key={index} className="product-panel">
              <ProductTab productType={productType} schema={schema} />
            </div>
          ))}
        </div>
        <div className="product-controls">
          <button onClick={() => addProduct("FX Vanilla")}>
            Add FX Vanilla
          </button>
          <button onClick={() => addProduct("FX Barrier")}>
            Add FX Barrier
          </button>
          {/* Add more product types as needed */}
        </div>
      </div>
    </LayoutProvider>
  );
};

export default App;
